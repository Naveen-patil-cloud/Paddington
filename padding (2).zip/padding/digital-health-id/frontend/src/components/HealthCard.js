import React from 'react';

const HealthCard = ({ healthData }) => {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-medium text-gray-900">
              {healthData.personalDetails?.name || 'Your Health Card'}
            </h3>
            <p className="text-sm text-gray-500">
              Patient ID: {healthData._id}
            </p>
          </div>
          <span className="px-3 py-1 bg-red-100 text-red-800 text-xs font-semibold rounded-full">
            EMERGENCY MODE
          </span>
        </div>
      </div>
      
      <div className="px-6 py-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-md font-medium text-gray-900 mb-3">Personal Details</h4>
            <div className="space-y-2">
              <p>
                <span className="text-sm text-gray-500">Date of Birth: </span>
                <span className="font-medium">
                  {healthData.personalDetails?.dob ? new Date(healthData.personalDetails.dob).toLocaleDateString() : 'Not specified'}
                </span>
              </p>
              <p>
                <span className="text-sm text-gray-500">Blood Group: </span>
                <span className="font-medium">
                  {healthData.personalDetails?.bloodGroup || 'Not specified'}
                </span>
              </p>
              <p>
                <span className="text-sm text-gray-500">Gender: </span>
                <span className="font-medium">
                  {healthData.personalDetails?.gender || 'Not specified'}
                </span>
              </p>
            </div>
          </div>
          
          <div>
            <h4 className="text-md font-medium text-gray-900 mb-3">Medical Information</h4>
            <div className="space-y-2">
              <p>
                <span className="text-sm text-gray-500">Allergies: </span>
                <span className="font-medium">
                  {healthData.allergies?.length > 0 ? healthData.allergies.join(', ') : 'None'}
                </span>
              </p>
              <p>
                <span className="text-sm text-gray-500">Conditions: </span>
                <span className="font-medium">
                  {healthData.medicalConditions?.length > 0 ? healthData.medicalConditions.join(', ') : 'None'}
                </span>
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-6">
          <h4 className="text-md font-medium text-gray-900 mb-3">Emergency Contact</h4>
          {healthData.emergencyContact ? (
            <p className="font-medium">
              {healthData.emergencyContact.name} ({healthData.emergencyContact.relation}) - {healthData.emergencyContact.phone}
            </p>
          ) : (
            <p className="text-gray-500">No emergency contact specified</p>
          )}
        </div>
      </div>
      
      <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <button className="text-indigo-600 hover:text-indigo-800 flex items-center">
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Export PDF
          </button>
        </div>
        <p className="text-sm text-gray-500">
          Last updated: {new Date(healthData.lastUpdated).toLocaleString()}
        </p>
      </div>
    </div>
  );
};

export default HealthCard;