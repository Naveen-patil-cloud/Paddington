const mongoose = require('mongoose');

const HealthDataSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  personalDetails: {
    name: String,
    dob: Date,
    bloodGroup: String,
    gender: String
  },
  allergies: [String],
  medicalConditions: [String],
  emergencyContact: {
    name: String,
    phone: String,
    relation: String
  },
  doctorVisits: [{
    doctorName: String,
    date: Date,
    notes: String
  }],
  medications: [{
    name: String,
    dosage: String,
    startDate: Date,
    endDate: Date
  }],
  testReports: [{
    name: String,
    date: Date,
    fileUrl: String
  }],
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('HealthData', HealthDataSchema);