const HealthData = require('../models/HealthData');

// @desc    Get user's health data
// @route   GET /api/health-data
exports.getHealthData = async (req, res) => {
  try {
    const healthData = await HealthData.findOne({ user: req.user.id });
    
    if (!healthData) {
      return res.status(404).json({ msg: 'Health data not found' });
    }
    
    res.json(healthData);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// @desc    Create or update health data
// @route   POST /api/health-data
exports.saveHealthData = async (req, res) => {
  const {
    personalDetails,
    allergies,
    medicalConditions,
    emergencyContact,
    doctorVisits,
    medications,
    testReports
  } = req.body;

  const healthDataFields = {
    user: req.user.id,
    personalDetails,
    allergies,
    medicalConditions,
    emergencyContact,
    doctorVisits,
    medications,
    testReports
  };

  try {
    let healthData = await HealthData.findOne({ user: req.user.id });

    if (healthData) {
      // Update existing
      healthData = await HealthData.findOneAndUpdate(
        { user: req.user.id },
        { $set: healthDataFields },
        { new: true }
      );
      return res.json(healthData);
    }

    // Create new
    healthData = new HealthData(healthDataFields);
    await healthData.save();
    res.json(healthData);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// @desc    Generate QR code data
// @route   GET /api/health-data/qr
exports.generateQRData = async (req, res) => {
  try {
    const healthData = await HealthData.findOne({ user: req.user.id })
      .select('personalDetails allergies medicalConditions emergencyContact');
    
    if (!healthData) {
      return res.status(404).json({ msg: 'Health data not found' });
    }
    
    res.json({
      qrData: JSON.stringify(healthData),
      timestamp: new Date()
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};