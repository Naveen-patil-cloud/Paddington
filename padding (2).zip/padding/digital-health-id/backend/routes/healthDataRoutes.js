const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const healthDataController = require('../controllers/healthDataController');

// @route   GET api/health-data
// @desc    Get user's health data
// @access  Private
router.get('/', auth, healthDataController.getHealthData);

// @route   POST api/health-data
// @desc    Create or update health data
// @access  Private
router.post('/', auth, healthDataController.saveHealthData);

// @route   GET api/health-data/qr
// @desc    Generate QR code data
// @access  Private
router.get('/qr', auth, healthDataController.generateQRData);

module.exports = router;