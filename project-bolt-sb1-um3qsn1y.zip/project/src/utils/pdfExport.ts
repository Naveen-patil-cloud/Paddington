import jsPDF from 'jspdf';
import { HealthRecord } from '../types/health';

export const exportHealthRecordToPDF = (healthRecord: HealthRecord): void => {
  const pdf = new jsPDF();
  const pageWidth = pdf.internal.pageSize.getWidth();
  const margin = 20;
  let yPosition = margin;

  // Title
  pdf.setFontSize(20);
  pdf.setTextColor(37, 99, 235); // Blue color
  pdf.text('Digital Health Record', margin, yPosition);
  yPosition += 15;

  // Patient Information
  pdf.setFontSize(16);
  pdf.setTextColor(0, 0, 0);
  pdf.text('Patient Information', margin, yPosition);
  yPosition += 10;

  pdf.setFontSize(12);
  const personalInfo = [
    `Name: ${healthRecord.personalDetails.name}`,
    `Date of Birth: ${healthRecord.personalDetails.dateOfBirth}`,
    `Blood Group: ${healthRecord.personalDetails.bloodGroup}`,
    `Gender: ${healthRecord.personalDetails.gender}`,
  ];

  personalInfo.forEach(info => {
    pdf.text(info, margin, yPosition);
    yPosition += 6;
  });

  yPosition += 5;

  // Emergency Contact
  pdf.setFontSize(16);
  pdf.text('Emergency Contact', margin, yPosition);
  yPosition += 10;

  pdf.setFontSize(12);
  const emergencyInfo = [
    `Name: ${healthRecord.emergencyContact.name}`,
    `Phone: ${healthRecord.emergencyContact.phoneNumber}`,
    `Relation: ${healthRecord.emergencyContact.relation}`,
  ];

  emergencyInfo.forEach(info => {
    pdf.text(info, margin, yPosition);
    yPosition += 6;
  });

  yPosition += 5;

  // Medical Conditions
  if (healthRecord.medicalConditions.length > 0) {
    pdf.setFontSize(16);
    pdf.text('Medical Conditions', margin, yPosition);
    yPosition += 10;

    pdf.setFontSize(12);
    healthRecord.medicalConditions.forEach(condition => {
      pdf.text(`• ${condition.condition} (${condition.severity})`, margin, yPosition);
      yPosition += 6;
    });
    yPosition += 5;
  }

  // Allergies
  if (healthRecord.allergies.length > 0) {
    pdf.setFontSize(16);
    pdf.text('Allergies', margin, yPosition);
    yPosition += 10;

    pdf.setFontSize(12);
    healthRecord.allergies.forEach(allergy => {
      pdf.text(`• ${allergy.allergen} - ${allergy.reaction} (${allergy.severity})`, margin, yPosition);
      yPosition += 6;
    });
    yPosition += 5;
  }

  // Check if we need a new page
  if (yPosition > 250) {
    pdf.addPage();
    yPosition = margin;
  }

  // Recent Medications
  if (healthRecord.medications.length > 0) {
    pdf.setFontSize(16);
    pdf.text('Current Medications', margin, yPosition);
    yPosition += 10;

    pdf.setFontSize(12);
    healthRecord.medications.slice(0, 5).forEach(medication => {
      pdf.text(`• ${medication.name} - ${medication.dosage} (${medication.frequency})`, margin, yPosition);
      yPosition += 6;
    });
  }

  // Footer
  pdf.setFontSize(10);
  pdf.setTextColor(128, 128, 128);
  pdf.text(`Generated on: ${new Date().toLocaleDateString()}`, margin, pdf.internal.pageSize.getHeight() - 10);

  // Save the PDF
  pdf.save(`${healthRecord.personalDetails.name}_health_record.pdf`);
};