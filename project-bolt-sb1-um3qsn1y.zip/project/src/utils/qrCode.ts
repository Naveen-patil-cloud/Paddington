import QRCode from 'qrcode';
import { HealthRecord } from '../types/health';

export const generateHealthQRCode = async (healthRecord: HealthRecord): Promise<string> => {
  const emergencyData = {
    name: healthRecord.personalDetails.name,
    bloodGroup: healthRecord.personalDetails.bloodGroup,
    emergencyContact: healthRecord.emergencyContact,
    allergies: healthRecord.allergies.map(a => ({
      allergen: a.allergen,
      severity: a.severity,
      reaction: a.reaction
    })),
    medicalConditions: healthRecord.medicalConditions.map(c => ({
      condition: c.condition,
      severity: c.severity
    })),
    timestamp: new Date().toISOString()
  };

  try {
    const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(emergencyData), {
      width: 300,
      margin: 2,
      color: {
        dark: '#2563eb',
        light: '#ffffff'
      }
    });
    return qrCodeDataURL;
  } catch (error) {
    console.error('Error generating QR code:', error);
    throw new Error('Failed to generate QR code');
  }
};

export const parseHealthQRCode = (qrData: string): any => {
  try {
    return JSON.parse(qrData);
  } catch (error) {
    console.error('Error parsing QR code data:', error);
    throw new Error('Invalid QR code data');
  }
};