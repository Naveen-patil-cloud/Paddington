import { HealthRecord } from '../types/health';

const STORAGE_KEY = 'digital_health_record';

export const saveHealthRecord = (healthRecord: HealthRecord): void => {
  try {
    const recordWithTimestamp = {
      ...healthRecord,
      updatedAt: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(recordWithTimestamp));
  } catch (error) {
    console.error('Error saving health record:', error);
    throw new Error('Failed to save health record');
  }
};

export const loadHealthRecord = (): HealthRecord | null => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return null;
    return JSON.parse(stored);
  } catch (error) {
    console.error('Error loading health record:', error);
    return null;
  }
};

export const clearHealthRecord = (): void => {
  localStorage.removeItem(STORAGE_KEY);
};

export const hasExistingRecord = (): boolean => {
  return localStorage.getItem(STORAGE_KEY) !== null;
};