import { UserRole, UserAccess } from '../types/health';

export const getRolePermissions = (role: UserRole): UserAccess => {
  switch (role) {
    case 'patient':
      return {
        role: 'patient',
        permissions: {
          viewPersonalDetails: true,
          editPersonalDetails: true,
          viewMedicalHistory: true,
          editMedicalHistory: true,
          viewEmergencyInfo: true,
          exportData: true,
        },
      };
    case 'family':
      return {
        role: 'family',
        permissions: {
          viewPersonalDetails: true,
          editPersonalDetails: false,
          viewMedicalHistory: true,
          editMedicalHistory: false,
          viewEmergencyInfo: true,
          exportData: false,
        },
      };
    case 'emergency':
      return {
        role: 'emergency',
        permissions: {
          viewPersonalDetails: false,
          editPersonalDetails: false,
          viewMedicalHistory: false,
          editMedicalHistory: false,
          viewEmergencyInfo: true,
          exportData: false,
        },
      };
    default:
      return getRolePermissions('emergency');
  }
};

export const canPerformAction = (role: UserRole, action: keyof UserAccess['permissions']): boolean => {
  const permissions = getRolePermissions(role);
  return permissions.permissions[action];
};