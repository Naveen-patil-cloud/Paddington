import React, { useState } from 'react';
import { PersonalDetails, EmergencyContact } from '../types/health';
import { User, Phone, Calendar, Droplets } from 'lucide-react';

interface PersonalDetailsFormProps {
  personalDetails: PersonalDetails;
  emergencyContact: EmergencyContact;
  onPersonalDetailsChange: (details: PersonalDetails) => void;
  onEmergencyContactChange: (contact: EmergencyContact) => void;
  canEdit: boolean;
}

const PersonalDetailsForm: React.FC<PersonalDetailsFormProps> = ({
  personalDetails,
  emergencyContact,
  onPersonalDetailsChange,
  onEmergencyContactChange,
  canEdit,
}) => {
  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const genders = ['Male', 'Female', 'Other', 'Prefer not to say'];
  const relations = ['Spouse', 'Parent', 'Child', 'Sibling', 'Friend', 'Other'];

  const handlePersonalChange = (field: keyof PersonalDetails, value: string) => {
    if (!canEdit) return;
    onPersonalDetailsChange({ ...personalDetails, [field]: value });
  };

  const handleEmergencyChange = (field: keyof EmergencyContact, value: string) => {
    if (!canEdit) return;
    onEmergencyContactChange({ ...emergencyContact, [field]: value });
  };

  return (
    <div className="space-y-8">
      {/* Personal Information */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center mb-6">
          <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mr-4">
            <User className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-semibold text-gray-800">Personal Information</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Full Name *
            </label>
            <input
              type="text"
              value={personalDetails.name}
              onChange={(e) => handlePersonalChange('name', e.target.value)}
              disabled={!canEdit}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors disabled:bg-gray-50 disabled:text-gray-500"
              placeholder="Enter your full name"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Date of Birth *
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <input
                type="date"
                value={personalDetails.dateOfBirth}
                onChange={(e) => handlePersonalChange('dateOfBirth', e.target.value)}
                disabled={!canEdit}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors disabled:bg-gray-50 disabled:text-gray-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Blood Group *
            </label>
            <div className="relative">
              <Droplets className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <select
                value={personalDetails.bloodGroup}
                onChange={(e) => handlePersonalChange('bloodGroup', e.target.value)}
                disabled={!canEdit}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors disabled:bg-gray-50 disabled:text-gray-500 appearance-none"
              >
                <option value="">Select blood group</option>
                {bloodGroups.map((group) => (
                  <option key={group} value={group}>
                    {group}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Gender *
            </label>
            <select
              value={personalDetails.gender}
              onChange={(e) => handlePersonalChange('gender', e.target.value)}
              disabled={!canEdit}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors disabled:bg-gray-50 disabled:text-gray-500 appearance-none"
            >
              <option value="">Select gender</option>
              {genders.map((gender) => (
                <option key={gender} value={gender}>
                  {gender}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Emergency Contact */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center mb-6">
          <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mr-4">
            <Phone className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-semibold text-gray-800">Emergency Contact</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Contact Name *
            </label>
            <input
              type="text"
              value={emergencyContact.name}
              onChange={(e) => handleEmergencyChange('name', e.target.value)}
              disabled={!canEdit}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors disabled:bg-gray-50 disabled:text-gray-500"
              placeholder="Emergency contact name"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phone Number *
            </label>
            <input
              type="tel"
              value={emergencyContact.phoneNumber}
              onChange={(e) => handleEmergencyChange('phoneNumber', e.target.value)}
              disabled={!canEdit}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors disabled:bg-gray-50 disabled:text-gray-500"
              placeholder="+1 (555) 123-4567"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Relationship *
            </label>
            <select
              value={emergencyContact.relation}
              onChange={(e) => handleEmergencyChange('relation', e.target.value)}
              disabled={!canEdit}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors disabled:bg-gray-50 disabled:text-gray-500 appearance-none"
            >
              <option value="">Select relationship</option>
              {relations.map((relation) => (
                <option key={relation} value={relation}>
                  {relation}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Alternate Phone
            </label>
            <input
              type="tel"
              value={emergencyContact.alternatePhone || ''}
              onChange={(e) => handleEmergencyChange('alternatePhone', e.target.value)}
              disabled={!canEdit}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors disabled:bg-gray-50 disabled:text-gray-500"
              placeholder="+1 (555) 987-6543"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalDetailsForm;