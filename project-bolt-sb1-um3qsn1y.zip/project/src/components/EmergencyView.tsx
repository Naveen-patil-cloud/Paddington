import React from 'react';
import { HealthRecord } from '../types/health';
import { 
  AlertTriangle, 
  Phone, 
  Droplets, 
  User, 
  Activity, 
  AlertCircle,
  Clock 
} from 'lucide-react';

interface EmergencyViewProps {
  healthRecord: HealthRecord;
}

const EmergencyView: React.FC<EmergencyViewProps> = ({ healthRecord }) => {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'mild': return 'bg-green-100 border-green-300 text-green-800';
      case 'moderate': return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      case 'severe': return 'bg-red-100 border-red-300 text-red-800';
      default: return 'bg-gray-100 border-gray-300 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-red-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Emergency Banner */}
        <div className="bg-red-600 text-white rounded-xl p-6 mb-6 shadow-lg">
          <div className="flex items-center justify-center mb-4">
            <AlertTriangle className="w-12 h-12 mr-4" />
            <div className="text-center">
              <h1 className="text-3xl font-bold">EMERGENCY ACCESS</h1>
              <p className="text-red-100 mt-2">Critical Health Information</p>
            </div>
          </div>
          <div className="text-center">
            <p className="text-sm text-red-100">
              <Clock className="w-4 h-4 inline mr-1" />
              Accessed: {new Date().toLocaleString()}
            </p>
          </div>
        </div>

        {/* Patient Identity */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6 border-l-4 border-red-500">
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mr-4">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">{healthRecord.personalDetails.name}</h2>
              <div className="flex items-center mt-2 space-x-4">
                <div className="flex items-center text-lg">
                  <Droplets className="w-5 h-5 text-red-500 mr-2" />
                  <span className="font-semibold text-red-600">
                    Blood Group: {healthRecord.personalDetails.bloodGroup}
                  </span>
                </div>
                <span className="text-gray-600">
                  {healthRecord.personalDetails.gender}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Emergency Contact */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6 border-l-4 border-blue-500">
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mr-4">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-xl font-bold text-gray-800">Emergency Contact</h2>
          </div>
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-blue-600 font-medium uppercase tracking-wide">Name</p>
                <p className="text-xl font-bold text-blue-800">{healthRecord.emergencyContact.name}</p>
              </div>
              <div>
                <p className="text-sm text-blue-600 font-medium uppercase tracking-wide">Phone</p>
                <p className="text-xl font-bold text-blue-800">
                  <a href={`tel:${healthRecord.emergencyContact.phoneNumber}`} className="hover:underline">
                    {healthRecord.emergencyContact.phoneNumber}
                  </a>
                </p>
              </div>
              <div>
                <p className="text-sm text-blue-600 font-medium uppercase tracking-wide">Relationship</p>
                <p className="text-lg font-semibold text-blue-800">{healthRecord.emergencyContact.relation}</p>
              </div>
              {healthRecord.emergencyContact.alternatePhone && (
                <div>
                  <p className="text-sm text-blue-600 font-medium uppercase tracking-wide">Alternate Phone</p>
                  <p className="text-lg font-semibold text-blue-800">
                    <a href={`tel:${healthRecord.emergencyContact.alternatePhone}`} className="hover:underline">
                      {healthRecord.emergencyContact.alternatePhone}
                    </a>
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Critical Allergies */}
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-orange-500">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mr-4">
                <AlertCircle className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-xl font-bold text-gray-800">CRITICAL ALLERGIES</h2>
            </div>
            {healthRecord.allergies.length > 0 ? (
              <div className="space-y-3">
                {healthRecord.allergies.map((allergy) => (
                  <div key={allergy.id} className={`p-4 border-2 rounded-lg ${getSeverityColor(allergy.severity)}`}>
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-bold">{allergy.allergen}</h3>
                      <span className="px-3 py-1 rounded-full text-sm font-bold border-2">
                        {allergy.severity.toUpperCase()}
                      </span>
                    </div>
                    <p className="font-semibold">Reaction: {allergy.reaction}</p>
                    {allergy.notes && (
                      <p className="text-sm mt-2 opacity-80">{allergy.notes}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <AlertCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p className="text-lg font-semibold">No Known Allergies</p>
              </div>
            )}
          </div>

          {/* Medical Conditions */}
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-teal-500">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-teal-500 rounded-full flex items-center justify-center mr-4">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-xl font-bold text-gray-800">MEDICAL CONDITIONS</h2>
            </div>
            {healthRecord.medicalConditions.length > 0 ? (
              <div className="space-y-3">
                {healthRecord.medicalConditions.map((condition) => (
                  <div key={condition.id} className={`p-4 border-2 rounded-lg ${getSeverityColor(condition.severity)}`}>
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-bold">{condition.condition}</h3>
                      <span className="px-3 py-1 rounded-full text-sm font-bold border-2">
                        {condition.severity.toUpperCase()}
                      </span>
                    </div>
                    {condition.diagnosedDate && (
                      <p className="font-semibold">Diagnosed: {condition.diagnosedDate}</p>
                    )}
                    {condition.notes && (
                      <p className="text-sm mt-2 opacity-80">{condition.notes}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Activity className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p className="text-lg font-semibold">No Medical Conditions</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-gray-500">
          <p className="text-sm">
            This is an emergency access view with limited health information.
            <br />
            For full medical records, please contact the patient or their healthcare provider.
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmergencyView;