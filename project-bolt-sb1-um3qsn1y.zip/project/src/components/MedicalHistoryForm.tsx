import React, { useState } from 'react';
import { DoctorVisit, Medication, TestReport } from '../types/health';
import { Stethoscope, Pill, FileText, Plus, Trash2, Calendar } from 'lucide-react';

interface MedicalHistoryFormProps {
  doctorVisits: DoctorVisit[];
  medications: Medication[];
  testReports: TestReport[];
  onDoctorVisitsChange: (visits: DoctorVisit[]) => void;
  onMedicationsChange: (medications: Medication[]) => void;
  onTestReportsChange: (reports: TestReport[]) => void;
  canEdit: boolean;
}

const MedicalHistoryForm: React.FC<MedicalHistoryFormProps> = ({
  doctorVisits,
  medications,
  testReports,
  onDoctorVisitsChange,
  onMedicationsChange,
  onTestReportsChange,
  canEdit,
}) => {
  const [activeTab, setActiveTab] = useState<'visits' | 'medications' | 'tests'>('visits');
  
  const [newVisit, setNewVisit] = useState<Partial<DoctorVisit>>({
    doctorName: '',
    specialty: '',
    visitDate: '',
    hospital: '',
    diagnosis: '',
    notes: '',
  });

  const [newMedication, setNewMedication] = useState<Partial<Medication>>({
    name: '',
    dosage: '',
    frequency: '',
    startDate: '',
    prescribedBy: '',
    notes: '',
  });

  const [newTest, setNewTest] = useState<Partial<TestReport>>({
    testName: '',
    testDate: '',
    laboratory: '',
    result: '',
    normalRange: '',
    notes: '',
  });

  const tabs = [
    { id: 'visits', label: 'Doctor Visits', icon: Stethoscope, count: doctorVisits.length },
    { id: 'medications', label: 'Medications', icon: Pill, count: medications.length },
    { id: 'tests', label: 'Test Reports', icon: FileText, count: testReports.length },
  ];

  const addVisit = () => {
    if (!canEdit || !newVisit.doctorName) return;
    const visit: DoctorVisit = {
      id: Date.now().toString(),
      doctorName: newVisit.doctorName!,
      specialty: newVisit.specialty || '',
      visitDate: newVisit.visitDate || '',
      hospital: newVisit.hospital || '',
      diagnosis: newVisit.diagnosis || '',
      notes: newVisit.notes || '',
    };
    onDoctorVisitsChange([...doctorVisits, visit]);
    setNewVisit({ doctorName: '', specialty: '', visitDate: '', hospital: '', diagnosis: '', notes: '' });
  };

  const removeVisit = (id: string) => {
    if (!canEdit) return;
    onDoctorVisitsChange(doctorVisits.filter(v => v.id !== id));
  };

  const addMedication = () => {
    if (!canEdit || !newMedication.name) return;
    const medication: Medication = {
      id: Date.now().toString(),
      name: newMedication.name!,
      dosage: newMedication.dosage || '',
      frequency: newMedication.frequency || '',
      startDate: newMedication.startDate || '',
      prescribedBy: newMedication.prescribedBy || '',
      notes: newMedication.notes || '',
    };
    onMedicationsChange([...medications, medication]);
    setNewMedication({ name: '', dosage: '', frequency: '', startDate: '', prescribedBy: '', notes: '' });
  };

  const removeMedication = (id: string) => {
    if (!canEdit) return;
    onMedicationsChange(medications.filter(m => m.id !== id));
  };

  const addTest = () => {
    if (!canEdit || !newTest.testName) return;
    const test: TestReport = {
      id: Date.now().toString(),
      testName: newTest.testName!,
      testDate: newTest.testDate || '',
      laboratory: newTest.laboratory || '',
      result: newTest.result || '',
      normalRange: newTest.normalRange || '',
      notes: newTest.notes || '',
    };
    onTestReportsChange([...testReports, test]);
    setNewTest({ testName: '', testDate: '', laboratory: '', result: '', normalRange: '', notes: '' });
  };

  const removeTest = (id: string) => {
    if (!canEdit) return;
    onTestReportsChange(testReports.filter(t => t.id !== id));
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-6">Medical History</h2>

      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-8 bg-gray-100 p-1 rounded-lg">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center px-4 py-2 rounded-md transition-colors flex-1 justify-center ${
                activeTab === tab.id
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4 mr-2" />
              <span className="font-medium">{tab.label}</span>
              <span className="ml-2 px-2 py-1 text-xs bg-gray-200 rounded-full">
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Doctor Visits Tab */}
      {activeTab === 'visits' && (
        <div className="space-y-6">
          {/* Existing Visits */}
          <div className="space-y-4">
            {doctorVisits.map((visit) => (
              <div key={visit.id} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <h3 className="font-semibold text-gray-800 mr-2">Dr. {visit.doctorName}</h3>
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                        {visit.specialty}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p><Calendar className="w-4 h-4 inline mr-1" /> {visit.visitDate}</p>
                      <p><strong>Hospital:</strong> {visit.hospital}</p>
                      <p><strong>Diagnosis:</strong> {visit.diagnosis}</p>
                      {visit.notes && <p><strong>Notes:</strong> {visit.notes}</p>}
                    </div>
                  </div>
                  {canEdit && (
                    <button
                      onClick={() => removeVisit(visit.id)}
                      className="ml-4 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Add New Visit */}
          {canEdit && (
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Add New Visit</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <input
                  type="text"
                  placeholder="Doctor Name"
                  value={newVisit.doctorName}
                  onChange={(e) => setNewVisit({ ...newVisit, doctorName: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="text"
                  placeholder="Specialty"
                  value={newVisit.specialty}
                  onChange={(e) => setNewVisit({ ...newVisit, specialty: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="date"
                  value={newVisit.visitDate}
                  onChange={(e) => setNewVisit({ ...newVisit, visitDate: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="text"
                  placeholder="Hospital/Clinic"
                  value={newVisit.hospital}
                  onChange={(e) => setNewVisit({ ...newVisit, hospital: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="text"
                  placeholder="Diagnosis"
                  value={newVisit.diagnosis}
                  onChange={(e) => setNewVisit({ ...newVisit, diagnosis: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <textarea
                  placeholder="Notes"
                  value={newVisit.notes}
                  onChange={(e) => setNewVisit({ ...newVisit, notes: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={3}
                />
              </div>
              <button
                onClick={addVisit}
                className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Visit
              </button>
            </div>
          )}
        </div>
      )}

      {/* Medications Tab */}
      {activeTab === 'medications' && (
        <div className="space-y-6">
          {/* Existing Medications */}
          <div className="space-y-4">
            {medications.map((medication) => (
              <div key={medication.id} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-2">{medication.name}</h3>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p><strong>Dosage:</strong> {medication.dosage}</p>
                      <p><strong>Frequency:</strong> {medication.frequency}</p>
                      <p><strong>Start Date:</strong> {medication.startDate}</p>
                      <p><strong>Prescribed By:</strong> {medication.prescribedBy}</p>
                      {medication.notes && <p><strong>Notes:</strong> {medication.notes}</p>}
                    </div>
                  </div>
                  {canEdit && (
                    <button
                      onClick={() => removeMedication(medication.id)}
                      className="ml-4 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Add New Medication */}
          {canEdit && (
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Add New Medication</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <input
                  type="text"
                  placeholder="Medication Name"
                  value={newMedication.name}
                  onChange={(e) => setNewMedication({ ...newMedication, name: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="text"
                  placeholder="Dosage (e.g., 500mg)"
                  value={newMedication.dosage}
                  onChange={(e) => setNewMedication({ ...newMedication, dosage: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="text"
                  placeholder="Frequency (e.g., Twice daily)"
                  value={newMedication.frequency}
                  onChange={(e) => setNewMedication({ ...newMedication, frequency: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="date"
                  value={newMedication.startDate}
                  onChange={(e) => setNewMedication({ ...newMedication, startDate: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="text"
                  placeholder="Prescribed By"
                  value={newMedication.prescribedBy}
                  onChange={(e) => setNewMedication({ ...newMedication, prescribedBy: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <textarea
                  placeholder="Notes"
                  value={newMedication.notes}
                  onChange={(e) => setNewMedication({ ...newMedication, notes: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={3}
                />
              </div>
              <button
                onClick={addMedication}
                className="flex items-center px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Medication
              </button>
            </div>
          )}
        </div>
      )}

      {/* Test Reports Tab */}
      {activeTab === 'tests' && (
        <div className="space-y-6">
          {/* Existing Tests */}
          <div className="space-y-4">
            {testReports.map((test) => (
              <div key={test.id} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-2">{test.testName}</h3>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p><strong>Date:</strong> {test.testDate}</p>
                      <p><strong>Laboratory:</strong> {test.laboratory}</p>
                      <p><strong>Result:</strong> {test.result}</p>
                      {test.normalRange && <p><strong>Normal Range:</strong> {test.normalRange}</p>}
                      {test.notes && <p><strong>Notes:</strong> {test.notes}</p>}
                    </div>
                  </div>
                  {canEdit && (
                    <button
                      onClick={() => removeTest(test.id)}
                      className="ml-4 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Add New Test */}
          {canEdit && (
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Add New Test Report</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <input
                  type="text"
                  placeholder="Test Name"
                  value={newTest.testName}
                  onChange={(e) => setNewTest({ ...newTest, testName: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="date"
                  value={newTest.testDate}
                  onChange={(e) => setNewTest({ ...newTest, testDate: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="text"
                  placeholder="Laboratory"
                  value={newTest.laboratory}
                  onChange={(e) => setNewTest({ ...newTest, laboratory: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="text"
                  placeholder="Result"
                  value={newTest.result}
                  onChange={(e) => setNewTest({ ...newTest, result: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="text"
                  placeholder="Normal Range"
                  value={newTest.normalRange}
                  onChange={(e) => setNewTest({ ...newTest, normalRange: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <textarea
                  placeholder="Notes"
                  value={newTest.notes}
                  onChange={(e) => setNewTest({ ...newTest, notes: e.target.value })}
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={3}
                />
              </div>
              <button
                onClick={addTest}
                className="flex items-center px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Test Report
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MedicalHistoryForm;