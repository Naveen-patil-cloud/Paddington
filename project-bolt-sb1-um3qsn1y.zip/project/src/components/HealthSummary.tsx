import React, { useState } from 'react';
import { HealthRecord } from '../types/health';
import { exportHealthRecordToPDF } from '../utils/pdfExport';
import { generateHealthQRCode } from '../utils/qrCode';
import { 
  Download, 
  QrCode, 
  User, 
  Phone, 
  Droplets, 
  Calendar, 
  AlertCircle, 
  Activity,
  Stethoscope,
  Pill,
  FileText,
  Share2
} from 'lucide-react';

interface HealthSummaryProps {
  healthRecord: HealthRecord;
  canExport: boolean;
}

const HealthSummary: React.FC<HealthSummaryProps> = ({ healthRecord, canExport }) => {
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [showQrCode, setShowQrCode] = useState(false);
  const [isGeneratingQr, setIsGeneratingQr] = useState(false);

  const handleExportPDF = () => {
    if (!canExport) return;
    exportHealthRecordToPDF(healthRecord);
  };

  const handleGenerateQRCode = async () => {
    if (!canExport) return;
    setIsGeneratingQr(true);
    try {
      const qrUrl = await generateHealthQRCode(healthRecord);
      setQrCodeUrl(qrUrl);
      setShowQrCode(true);
    } catch (error) {
      console.error('Failed to generate QR code:', error);
    } finally {
      setIsGeneratingQr(false);
    }
  };

  const calculateAge = (dateOfBirth: string) => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'mild': return 'text-green-600 bg-green-50 border-green-200';
      case 'moderate': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'severe': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Card */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl shadow-lg p-8 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-6">
              <User className="w-10 h-10" />
            </div>
            <div>
              <h1 className="text-3xl font-bold mb-2">{healthRecord.personalDetails.name}</h1>
              <div className="flex items-center space-x-6 text-blue-100">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>Age {calculateAge(healthRecord.personalDetails.dateOfBirth)}</span>
                </div>
                <div className="flex items-center">
                  <Droplets className="w-4 h-4 mr-2" />
                  <span>{healthRecord.personalDetails.bloodGroup}</span>
                </div>
                <span className="px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm">
                  {healthRecord.personalDetails.gender}
                </span>
              </div>
            </div>
          </div>
          
          {canExport && (
            <div className="flex space-x-3">
              <button
                onClick={handleExportPDF}
                className="flex items-center px-4 py-2 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg transition-colors"
              >
                <Download className="w-4 h-4 mr-2" />
                Export PDF
              </button>
              <button
                onClick={handleGenerateQRCode}
                disabled={isGeneratingQr}
                className="flex items-center px-4 py-2 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg transition-colors disabled:opacity-50"
              >
                <QrCode className="w-4 h-4 mr-2" />
                {isGeneratingQr ? 'Generating...' : 'QR Code'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Emergency Contact */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center mb-4">
          <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center mr-3">
            <Phone className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-xl font-semibold text-gray-800">Emergency Contact</h2>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-red-600 font-medium">Name</p>
              <p className="text-red-800 font-semibold">{healthRecord.emergencyContact.name}</p>
            </div>
            <div>
              <p className="text-sm text-red-600 font-medium">Phone</p>
              <p className="text-red-800 font-semibold">{healthRecord.emergencyContact.phoneNumber}</p>
            </div>
            <div>
              <p className="text-sm text-red-600 font-medium">Relationship</p>
              <p className="text-red-800 font-semibold">{healthRecord.emergencyContact.relation}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Medical Conditions & Allergies */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Medical Conditions */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center mb-4">
            <div className="w-10 h-10 bg-teal-500 rounded-full flex items-center justify-center mr-3">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-gray-800">Medical Conditions</h2>
          </div>
          {healthRecord.medicalConditions.length > 0 ? (
            <div className="space-y-3">
              {healthRecord.medicalConditions.map((condition) => (
                <div key={condition.id} className={`p-3 border rounded-lg ${getSeverityColor(condition.severity)}`}>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{condition.condition}</span>
                    <span className="text-xs px-2 py-1 rounded-full border">
                      {condition.severity}
                    </span>
                  </div>
                  {condition.diagnosedDate && (
                    <p className="text-sm mt-1 opacity-75">
                      Diagnosed: {condition.diagnosedDate}
                    </p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 italic">No medical conditions recorded</p>
          )}
        </div>

        {/* Allergies */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center mb-4">
            <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center mr-3">
              <AlertCircle className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-gray-800">Allergies</h2>
          </div>
          {healthRecord.allergies.length > 0 ? (
            <div className="space-y-3">
              {healthRecord.allergies.map((allergy) => (
                <div key={allergy.id} className={`p-3 border rounded-lg ${getSeverityColor(allergy.severity)}`}>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{allergy.allergen}</span>
                    <span className="text-xs px-2 py-1 rounded-full border">
                      {allergy.severity}
                    </span>
                  </div>
                  <p className="text-sm mt-1 opacity-75">
                    Reaction: {allergy.reaction}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 italic">No allergies recorded</p>
          )}
        </div>
      </div>

      {/* Medical History Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6 text-center">
          <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Stethoscope className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Doctor Visits</h3>
          <p className="text-3xl font-bold text-blue-600">{healthRecord.doctorVisits.length}</p>
          <p className="text-sm text-gray-500">Total visits recorded</p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 text-center">
          <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Pill className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Medications</h3>
          <p className="text-3xl font-bold text-green-600">{healthRecord.medications.length}</p>
          <p className="text-sm text-gray-500">Current medications</p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 text-center">
          <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Test Reports</h3>
          <p className="text-3xl font-bold text-purple-600">{healthRecord.testReports.length}</p>
          <p className="text-sm text-gray-500">Lab tests recorded</p>
        </div>
      </div>

      {/* QR Code Modal */}
      {showQrCode && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
            <div className="text-center">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Emergency Health QR Code</h3>
              <div className="bg-gray-50 p-6 rounded-lg mb-4">
                <img src={qrCodeUrl} alt="Health QR Code" className="mx-auto" />
              </div>
              <p className="text-sm text-gray-600 mb-6">
                Scan this QR code to access emergency health information including blood group, 
                allergies, medical conditions, and emergency contact details.
              </p>
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowQrCode(false)}
                  className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const link = document.createElement('a');
                    link.download = 'health-qr-code.png';
                    link.href = qrCodeUrl;
                    link.click();
                  }}
                  className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HealthSummary;