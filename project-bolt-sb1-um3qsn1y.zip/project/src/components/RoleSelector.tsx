import React from 'react';
import { UserRole } from '../types/health';
import { User, Users, AlertTriangle } from 'lucide-react';

interface RoleSelectorProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
}

const RoleSelector: React.FC<RoleSelectorProps> = ({ currentRole, onRoleChange }) => {
  const roles = [
    {
      id: 'patient' as UserRole,
      name: 'Patient',
      description: 'Full access to manage health records',
      icon: User,
      color: 'bg-blue-500',
    },
    {
      id: 'family' as UserRole,
      name: 'Family Member',
      description: 'Read-only access to health information',
      icon: Users,
      color: 'bg-teal-500',
    },
    {
      id: 'emergency' as UserRole,
      name: 'Emergency Access',
      description: 'Limited access to critical information only',
      icon: AlertTriangle,
      color: 'bg-red-500',
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Access Role</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {roles.map((role) => {
          const Icon = role.icon;
          const isSelected = currentRole === role.id;
          
          return (
            <button
              key={role.id}
              onClick={() => onRoleChange(role.id)}
              className={`p-4 rounded-lg border-2 transition-all duration-200 text-left hover:shadow-md ${
                isSelected
                  ? 'border-blue-500 bg-blue-50 shadow-md'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center mb-3">
                <div className={`w-10 h-10 rounded-full ${role.color} flex items-center justify-center mr-3`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-semibold text-gray-800">{role.name}</h3>
              </div>
              <p className="text-sm text-gray-600">{role.description}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default RoleSelector;