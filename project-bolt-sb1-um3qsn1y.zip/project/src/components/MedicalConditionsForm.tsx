import React, { useState } from 'react';
import { MedicalCondition, Allergy } from '../types/health';
import { AlertCircle, Plus, Trash2, Activity } from 'lucide-react';

interface MedicalConditionsFormProps {
  medicalConditions: MedicalCondition[];
  allergies: Allergy[];
  onMedicalConditionsChange: (conditions: MedicalCondition[]) => void;
  onAllergiesChange: (allergies: Allergy[]) => void;
  canEdit: boolean;
}

const MedicalConditionsForm: React.FC<MedicalConditionsFormProps> = ({
  medicalConditions,
  allergies,
  onMedicalConditionsChange,
  onAllergiesChange,
  canEdit,
}) => {
  const [newCondition, setNewCondition] = useState<Partial<MedicalCondition>>({
    condition: '',
    severity: 'mild',
    diagnosedDate: '',
    notes: '',
  });

  const [newAllergy, setNewAllergy] = useState<Partial<Allergy>>({
    allergen: '',
    severity: 'mild',
    reaction: '',
    notes: '',
  });

  const severityOptions = [
    { value: 'mild', label: 'Mild', color: 'text-green-600 bg-green-50' },
    { value: 'moderate', label: 'Moderate', color: 'text-yellow-600 bg-yellow-50' },
    { value: 'severe', label: 'Severe', color: 'text-red-600 bg-red-50' },
  ];

  const addCondition = () => {
    if (!canEdit || !newCondition.condition) return;

    const condition: MedicalCondition = {
      id: Date.now().toString(),
      condition: newCondition.condition,
      severity: newCondition.severity as 'mild' | 'moderate' | 'severe',
      diagnosedDate: newCondition.diagnosedDate || '',
      notes: newCondition.notes || '',
    };

    onMedicalConditionsChange([...medicalConditions, condition]);
    setNewCondition({ condition: '', severity: 'mild', diagnosedDate: '', notes: '' });
  };

  const removeCondition = (id: string) => {
    if (!canEdit) return;
    onMedicalConditionsChange(medicalConditions.filter(c => c.id !== id));
  };

  const addAllergy = () => {
    if (!canEdit || !newAllergy.allergen) return;

    const allergy: Allergy = {
      id: Date.now().toString(),
      allergen: newAllergy.allergen,
      severity: newAllergy.severity as 'mild' | 'moderate' | 'severe',
      reaction: newAllergy.reaction || '',
      notes: newAllergy.notes || '',
    };

    onAllergiesChange([...allergies, allergy]);
    setNewAllergy({ allergen: '', severity: 'mild', reaction: '', notes: '' });
  };

  const removeAllergy = (id: string) => {
    if (!canEdit) return;
    onAllergiesChange(allergies.filter(a => a.id !== id));
  };

  const getSeverityStyle = (severity: string) => {
    const option = severityOptions.find(opt => opt.value === severity);
    return option ? option.color : 'text-gray-600 bg-gray-50';
  };

  return (
    <div className="space-y-8">
      {/* Medical Conditions */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center mb-6">
          <div className="w-12 h-12 bg-teal-500 rounded-full flex items-center justify-center mr-4">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-semibold text-gray-800">Medical Conditions</h2>
        </div>

        {/* Existing Conditions */}
        <div className="space-y-4 mb-6">
          {medicalConditions.map((condition) => (
            <div key={condition.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex-1">
                <div className="flex items-center mb-2">
                  <h3 className="font-semibold text-gray-800 mr-3">{condition.condition}</h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityStyle(condition.severity)}`}>
                    {condition.severity}
                  </span>
                </div>
                <p className="text-sm text-gray-600">Diagnosed: {condition.diagnosedDate}</p>
                {condition.notes && (
                  <p className="text-sm text-gray-600 mt-1">{condition.notes}</p>
                )}
              </div>
              {canEdit && (
                <button
                  onClick={() => removeCondition(condition.id)}
                  className="ml-4 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Add New Condition */}
        {canEdit && (
          <div className="border-t pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Condition Name
                </label>
                <input
                  type="text"
                  value={newCondition.condition}
                  onChange={(e) => setNewCondition({ ...newCondition, condition: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Diabetes, Hypertension"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Severity
                </label>
                <select
                  value={newCondition.severity}
                  onChange={(e) => setNewCondition({ ...newCondition, severity: e.target.value as any })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {severityOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Diagnosed Date
                </label>
                <input
                  type="date"
                  value={newCondition.diagnosedDate}
                  onChange={(e) => setNewCondition({ ...newCondition, diagnosedDate: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notes
                </label>
                <input
                  type="text"
                  value={newCondition.notes}
                  onChange={(e) => setNewCondition({ ...newCondition, notes: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Additional notes"
                />
              </div>
            </div>
            <button
              onClick={addCondition}
              className="flex items-center px-4 py-2 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Condition
            </button>
          </div>
        )}
      </div>

      {/* Allergies */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center mb-6">
          <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mr-4">
            <AlertCircle className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-semibold text-gray-800">Allergies</h2>
        </div>

        {/* Existing Allergies */}
        <div className="space-y-4 mb-6">
          {allergies.map((allergy) => (
            <div key={allergy.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex-1">
                <div className="flex items-center mb-2">
                  <h3 className="font-semibold text-gray-800 mr-3">{allergy.allergen}</h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityStyle(allergy.severity)}`}>
                    {allergy.severity}
                  </span>
                </div>
                <p className="text-sm text-gray-600">Reaction: {allergy.reaction}</p>
                {allergy.notes && (
                  <p className="text-sm text-gray-600 mt-1">{allergy.notes}</p>
                )}
              </div>
              {canEdit && (
                <button
                  onClick={() => removeAllergy(allergy.id)}
                  className="ml-4 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Add New Allergy */}
        {canEdit && (
          <div className="border-t pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Allergen
                </label>
                <input
                  type="text"
                  value={newAllergy.allergen}
                  onChange={(e) => setNewAllergy({ ...newAllergy, allergen: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Peanuts, Shellfish"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Severity
                </label>
                <select
                  value={newAllergy.severity}
                  onChange={(e) => setNewAllergy({ ...newAllergy, severity: e.target.value as any })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {severityOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reaction
                </label>
                <input
                  type="text"
                  value={newAllergy.reaction}
                  onChange={(e) => setNewAllergy({ ...newAllergy, reaction: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Hives, Difficulty breathing"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notes
                </label>
                <input
                  type="text"
                  value={newAllergy.notes}
                  onChange={(e) => setNewAllergy({ ...newAllergy, notes: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Additional notes"
                />
              </div>
            </div>
            <button
              onClick={addAllergy}
              className="flex items-center px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Allergy
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default MedicalConditionsForm;