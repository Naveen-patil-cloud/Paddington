export interface PersonalDetails {
  id: string;
  name: string;
  dateOfBirth: string;
  bloodGroup: string;
  gender: string;
  profileImage?: string;
}

export interface EmergencyContact {
  name: string;
  phoneNumber: string;
  relation: string;
  alternatePhone?: string;
}

export interface MedicalCondition {
  id: string;
  condition: string;
  severity: 'mild' | 'moderate' | 'severe';
  diagnosedDate: string;
  notes?: string;
}

export interface Allergy {
  id: string;
  allergen: string;
  severity: 'mild' | 'moderate' | 'severe';
  reaction: string;
  notes?: string;
}

export interface DoctorVisit {
  id: string;
  doctorName: string;
  specialty: string;
  visitDate: string;
  hospital: string;
  diagnosis: string;
  notes: string;
  followUpDate?: string;
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  startDate: string;
  endDate?: string;
  prescribedBy: string;
  notes?: string;
}

export interface TestReport {
  id: string;
  testName: string;
  testDate: string;
  laboratory: string;
  result: string;
  normalRange?: string;
  notes?: string;
}

export interface HealthRecord {
  personalDetails: PersonalDetails;
  emergencyContact: EmergencyContact;
  medicalConditions: MedicalCondition[];
  allergies: Allergy[];
  doctorVisits: DoctorVisit[];
  medications: Medication[];
  testReports: TestReport[];
  createdAt: string;
  updatedAt: string;
}

export type UserRole = 'patient' | 'family' | 'emergency';

export interface UserAccess {
  role: UserRole;
  permissions: {
    viewPersonalDetails: boolean;
    editPersonalDetails: boolean;
    viewMedicalHistory: boolean;
    editMedicalHistory: boolean;
    viewEmergencyInfo: boolean;
    exportData: boolean;
  };
}